extends Node2D

var player: CharacterBody2D
var enemies: Array[Dictionary] = []
var floating_text: Array[Dictionary] = []
var toast: String = "استكشف قرية إيوُرا وابحث عن بوابة الزنزانة"
var toast_time: float = 4.0
var panel_mode: String = ""
var font: Font

func _ready() -> void:
	player = $Player
	font = ThemeDB.fallback_font
	_spawn_enemies()
	queue_redraw()

func _process(delta: float) -> void:
	toast_time = max(0.0, toast_time - delta)
	for e in enemies:
		if not bool(e["alive"]):
			continue
		var enemy_pos: Vector2 = e["pos"]
		var d: float = enemy_pos.distance_to(player.global_position)
		if d < 220.0:
			e["pos"] = enemy_pos + enemy_pos.direction_to(player.global_position) * delta * 22.0
	for t in floating_text:
		var text_pos: Vector2 = t["pos"]
		t["pos"] = text_pos + Vector2(0.0, -delta * 28.0)
		t["life"] = float(t["life"]) - delta
	floating_text = floating_text.filter(func(x): return float(x["life"]) > 0.0)
	queue_redraw()

func _spawn_enemies() -> void:
	enemies = [
		{"pos":Vector2(820,360),"hp":120.0,"max_hp":120.0,"alive":true,"name":"حارس الغابة"},
		{"pos":Vector2(930,500),"hp":180.0,"max_hp":180.0,"alive":true,"name":"ذئب الظلال"},
		{"pos":Vector2(1050,300),"hp":360.0,"max_hp":360.0,"alive":true,"name":"زعيم الزنزانة"}
	]

func player_attack(origin: Vector2, facing: Vector2) -> void:
	var best: int = -1
	var best_d: float = 90.0
	for i in range(enemies.size()):
		if not bool(enemies[i]["alive"]):
			continue
		var enemy_pos: Vector2 = enemies[i]["pos"]
		var to_enemy: Vector2 = enemy_pos - origin
		var d: float = to_enemy.length()
		if d < best_d and facing.dot(to_enemy.normalized()) > 0.25:
			best = i
			best_d = d
	if best >= 0:
		var damage: int = randi_range(24, 38)
		enemies[best]["hp"] = float(enemies[best]["hp"]) - float(damage)
		var hit_pos: Vector2 = enemies[best]["pos"]
		var enemy_name: String = str(enemies[best]["name"])
		floating_text.append({"pos": hit_pos + Vector2(0,-35), "text":"-%d" % damage, "life":0.9})
		toast = "ضربة ناجحة! %s" % enemy_name
		toast_time = 1.2
		if float(enemies[best]["hp"]) <= 0.0:
			enemies[best]["alive"] = false
			toast = "تم هزيمة %s — +120 XP" % enemy_name
			toast_time = 2.5

func _draw() -> void:
	_draw_world()
	_draw_enemies()
	_draw_player_marker()
	_draw_hud()

func _draw_world() -> void:
	draw_rect(Rect2(0,0,1280,720), Color("#0a1820"))
	# soft ground tiles
	for y in range(70, 720, 80):
		for x in range(0, 1280, 80):
			var alt: Color = Color("#3a574d") if ((x / 80 + y / 80) as int) % 2 == 0 else Color("#344f48")
			draw_rect(Rect2(x,y,80,80), alt)
	# road
	draw_colored_polygon(PackedVector2Array([Vector2(0,470),Vector2(1280,380),Vector2(1280,520),Vector2(0,610)]),Color("#6d604e"))
	draw_colored_polygon(PackedVector2Array([Vector2(0,490),Vector2(1280,400),Vector2(1280,418),Vector2(0,510)]),Color("#8a765b"))
	# village
	_draw_building(Vector2(170,250), "قرية إيوُرا")
	_draw_building(Vector2(390,180), "دار المغامرين")
	_draw_building(Vector2(1010,210), "بوابة الزنزانة")
	# forest clusters
	for p in [Vector2(70,170),Vector2(100,300),Vector2(1150,130),Vector2(1200,580),Vector2(170,620),Vector2(1090,640)]:
		_draw_tree(p)
	# shrine
	draw_circle(Vector2(640,170),38,Color("#172c3d"))
	draw_rect(Rect2(626,128,28,52),Color("#8b9db1"),true)
	draw_rect(Rect2(616,135,48,9),Color("#d8e4ee"),true)
	draw_string(font,Vector2(590,215),"كاهن دو-يون",HORIZONTAL_ALIGNMENT_LEFT,150,18,Color("#f3e6c2"))

func _draw_tree(p: Vector2) -> void:
	_draw_oval(p+Vector2(0,25),Vector2(34,12),Color(0.02,0.04,0.05,0.45))
	draw_rect(Rect2(p.x-7,p.y+3,14,35),Color("#493a2d"),true)
	draw_circle(p+Vector2(-15,0),24,Color("#163b32"))
	draw_circle(p+Vector2(12,-5),28,Color("#1d5140"))
	draw_circle(p+Vector2(0,-22),27,Color("#28634c"))
	draw_circle(p+Vector2(-6,-28),8,Color("#3e8761"))

func _draw_building(p: Vector2, label: String) -> void:
	draw_colored_polygon(PackedVector2Array([p+Vector2(-75,30),p+Vector2(0,-30),p+Vector2(75,30),p+Vector2(75,95),p+Vector2(-75,95)]),Color("#6b5142"))
	draw_colored_polygon(PackedVector2Array([p+Vector2(-88,30),p+Vector2(0,-45),p+Vector2(88,30)]),Color("#283a4d"))
	draw_rect(Rect2(p.x-15,p.y+48,30,47),Color("#30261f"),true)
	draw_string(font,p+Vector2(-75,120),label,HORIZONTAL_ALIGNMENT_LEFT,170,16,Color("#f2e3bd"))

func _draw_enemies() -> void:
	for e in enemies:
		if not bool(e["alive"]):
			continue
		var p: Vector2 = e["pos"]
		_draw_oval(p+Vector2(0,20),Vector2(24,8),Color(0.02,0.03,0.04,0.5))
		var boss: bool = float(e["max_hp"]) > 300.0
		draw_circle(p, 22 if not boss else 29, Color("#8b3c4b") if not boss else Color("#5b2e73"))
		draw_circle(p+Vector2(-7,-5),4,Color("#ffdf9a"))
		draw_circle(p+Vector2(7,-5),4,Color("#ffdf9a"))
		var w: float = 62.0 if not boss else 82.0
		draw_rect(Rect2(p.x-w/2,p.y-43,w,6),Color("#17222d"),true)
		draw_rect(Rect2(p.x-w/2,p.y-43,w*clamp(float(e["hp"])/float(e["max_hp"]), 0.0, 1.0),6),Color("#e05262") if not boss else Color("#b56cf0"),true)
		draw_string(font,p+Vector2(-45,-51),str(e["name"]),HORIZONTAL_ALIGNMENT_LEFT,100,10,Color("#f1dcb2"))

func _draw_player_marker() -> void:
	draw_circle(player.global_position+Vector2(0,31),33,Color(0.25,0.8,1,0.08))
	draw_arc(player.global_position+Vector2(0,31),31,0,TAU,40,Color(0.35,0.8,1,0.35),2)

func _draw_hud() -> void:
	# Top-left resources
	_draw_panel(Rect2(18,18,360,88),Color("#0b1621"))
	draw_string(font,Vector2(35,47),"الحارس نول",HORIZONTAL_ALIGNMENT_LEFT,160,21,Color("#ffe1a0"))
	draw_string(font,Vector2(210,47),"Lv. 10",HORIZONTAL_ALIGNMENT_LEFT,100,19,Color("#9fdcff"))
	_draw_bar(Vector2(35,60),300,10,player.hp/player.max_hp,Color("#e85a68"))
	draw_string(font,Vector2(35,90),"HP  %d / %d" % [player.hp,player.max_hp],HORIZONTAL_ALIGNMENT_LEFT,140,12,Color("#dbe7f2"))
	draw_string(font,Vector2(190,90),"⚔ %d   🛡 43   💥 12%%" % player.attack_power,HORIZONTAL_ALIGNMENT_LEFT,160,12,Color("#c8d4df"))
	# resources
	_draw_pill(Vector2(400,18),120,"29  ✦")
	_draw_pill(Vector2(530,18),120,"24  ◆")
	_draw_pill(Vector2(660,18),150,"2480  ◉")
	# Quest panel
	_draw_panel(Rect2(18,126,310,116),Color("#0b1621"))
	draw_string(font,Vector2(35,153),"المهمة الحالية",HORIZONTAL_ALIGNMENT_LEFT,260,20,Color("#ffd86d"))
	draw_string(font,Vector2(35,181),"استكشف بوابة الزنزانة",HORIZONTAL_ALIGNMENT_LEFT,260,15,Color("#f4f7fa"))
	draw_string(font,Vector2(35,208),"المكافأة: XP 180 + معدات نادرة",HORIZONTAL_ALIGNMENT_LEFT,260,12,Color("#9fdcff"))
	# Minimap
	_draw_panel(Rect2(1010,18,250,170),Color("#08131d"))
	draw_string(font,Vector2(1030,44),"خريطة إيورا",HORIZONTAL_ALIGNMENT_LEFT,210,17,Color("#f5dfab"))
	draw_rect(Rect2(1028,56,214,110),Color("#173c35"),true)
	draw_line(Vector2(1038,115),Vector2(1235,78),Color("#8d7658"),12)
	for e in enemies:
		if bool(e["alive"]):
			var enemy_pos: Vector2 = e["pos"]
			var mp: Vector2 = Vector2(1028,56)+(enemy_pos/Vector2(1280,720))*Vector2(214,110)
			draw_circle(mp,4,Color("#d05a6b"))
	var pp: Vector2 = Vector2(1028,56)+(player.global_position/Vector2(1280,720))*Vector2(214,110)
	draw_circle(pp,5,Color("#72d9ff"))
	# Bottom hint
	_draw_panel(Rect2(470,650,340,50),Color("#08131d"))
	draw_string(font,Vector2(490,682),"WASD للحركة  •  المس/اضغط للهجوم",HORIZONTAL_ALIGNMENT_LEFT,310,13,Color("#c7d5e0"))
	# toast
	if toast_time > 0.0:
		var a: float = minf(1.0, toast_time)
		draw_rect(Rect2(440,108,400,42),Color(0.03,0.07,0.1,0.88*a),true)
		draw_string(font,Vector2(460,135),toast,HORIZONTAL_ALIGNMENT_LEFT,360,13,Color("#f3e2b4"))
	for t in floating_text:
		draw_string(font,t["pos"],str(t["text"]),HORIZONTAL_ALIGNMENT_CENTER,80,18,Color("#ffd76a"))

func _draw_panel(r: Rect2, c: Color) -> void:
	draw_style_box(_make_box(c,Color("#d6b45a55")),r)

func _draw_pill(p: Vector2,w: float,txt: String) -> void:
	draw_style_box(_make_box(Color("#0e1e2d"),Color("#d6b45a33"),18),Rect2(p.x,p.y,w,40))
	draw_string(font,p+Vector2(14,26),txt,HORIZONTAL_ALIGNMENT_LEFT,w-20,15,Color("#ffe5a3"))

func _draw_bar(p: Vector2,w: float,h: float,v: float,c: Color) -> void:
	draw_rect(Rect2(p.x,p.y,w,h),Color("#162431"),true)
	draw_rect(Rect2(p.x,p.y,w*clamp(v,0.0,1.0),h),c,true)

func _make_box(bg: Color, border: Color, radius := 14) -> StyleBoxFlat:
	var s: StyleBoxFlat = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.corner_radius_top_left = radius
	s.corner_radius_top_right = radius
	s.corner_radius_bottom_left = radius
	s.corner_radius_bottom_right = radius
	return s

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(25):
		var a: float = TAU * float(i) / 24.0
		pts.append(center + Vector2(cos(a)*radii.x, sin(a)*radii.y))
	draw_colored_polygon(pts, color)
