extends CharacterBody2D

var speed: float = 230.0
var stamina: float = 100.0
var hp: float = 336.0
var max_hp: float = 336.0
var attack_power: int = 77
var facing: Vector2 = Vector2.DOWN
var attack_timer: float = 0.0
var hit_flash: float = 0.0

func _ready() -> void:
	queue_redraw()

func _physics_process(delta: float) -> void:
	var input_vec: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if input_vec.length() > 0.05:
		facing = input_vec.normalized()
		velocity = input_vec * speed
	else:
		velocity = Vector2.ZERO
	move_and_slide()
	global_position.x = clamp(global_position.x, 90.0, 1190.0)
	global_position.y = clamp(global_position.y, 120.0, 680.0)
	stamina = min(100.0, stamina + delta * 18.0)
	attack_timer = max(0.0, attack_timer - delta)
	hit_flash = max(0.0, hit_flash - delta)
	if Input.is_action_just_pressed("attack"):
		attack()
	queue_redraw()

func attack() -> void:
	if attack_timer > 0.0:
		return
	attack_timer = 0.42
	stamina = max(0.0, stamina - 8.0)
	get_parent().player_attack(global_position, facing)

func _draw() -> void:
    # Diagnostic: temporarily disable player custom drawing.
    pass


func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(25):
		var a: float = TAU * float(i) / 24.0
		pts.append(center + Vector2(cos(a)*radii.x, sin(a)*radii.y))
	draw_colored_polygon(pts, color)
