package com.example.pickmeup;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){const ms=[...document.querySelectorAll('.modal')];for(let i=ms.length-1;i>=0;i--){if(getComputedStyle(ms[i]).display!=='none'){ms[i].style.display='none';if(ms[i].id==='mapModal'&&window.mapPulse){clearInterval(window.mapPulse);window.mapPulse=null;}return 'closed';}}return 'none';})()", value -> {
            if (!"\"closed\"".equals(value)) {
                if (web.canGoBack()) web.goBack(); else super.onBackPressed();
            }
        });
    }
}
