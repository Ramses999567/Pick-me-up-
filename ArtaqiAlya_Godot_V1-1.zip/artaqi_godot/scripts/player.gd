extends CharacterBody2D

var speed := 230.0
var stamina := 100.0
var hp := 336.0
var max_hp := 336.0
var attack_power := 77
var facing := Vector2.DOWN
var attack_timer := 0.0
var hit_flash := 0.0

func _ready() -> void:
	queue_redraw()

func _physics_process(delta: float) -> void:
	var input_vec: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if input_vec.length() > 0.05:
		facing = input_vec.normalized()
		velocity = input_vec * speed
	else:
		velocity = Vector2.ZERO
	move_and_slide()
	global_position.x = clamp(global_position.x, 90.0, 1190.0)
	global_position.y = clamp(global_position.y, 120.0, 680.0)
	stamina = min(100.0, stamina + delta * 18.0)
	attack_timer = max(0.0, attack_timer - delta)
	hit_flash = max(0.0, hit_flash - delta)
	if Input.is_action_just_pressed("attack"):
		attack()
	queue_redraw()

func attack() -> void:
	if attack_timer > 0.0:
		return
	attack_timer = 0.42
	stamina = max(0.0, stamina - 8.0)
	get_parent().player_attack(global_position, facing)

func _draw() -> void:
	# Shadow
	draw_ellipse(Vector2(0, 19), Vector2(27, 10), Color(0.02,0.03,0.04,0.55))
	# Cape/body
	var body_color: Color = Color("#3b477a") if hit_flash <= 0.0 else Color("#f2d6d6")
	var cape: PackedVector2Array = PackedVector2Array([Vector2(-17,8),Vector2(0,-7),Vector2(17,8),Vector2(12,30),Vector2(-13,30)])
	draw_colored_polygon(cape, Color("#642f58"))
	draw_rect(Rect2(-13,5,26,27), body_color, true)
	# scarf
	draw_colored_polygon(PackedVector2Array([Vector2(8,-4),Vector2(24,2),Vector2(15,9),Vector2(5,4)]), Color("#d94e55"))
	# head
	draw_circle(Vector2(0,-18), 16, Color("#e8c9ae"))
	draw_arc(Vector2(0,-18),16,PI,TAU,20,Color("#151c2a"),7)
	# sword
	var dir: Vector2 = facing.normalized()
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var grip: Vector2 = dir * 8
	var tip: Vector2 = dir * 64
	draw_line(grip + side*5, grip - side*5, Color("#b77b4e"), 7)
	draw_line(grip + side*7, tip, Color("#e9f4ff"), 8)
	draw_line(grip + side*7, tip, Color("#8ec7e8"), 3)

func draw_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(25):
		var a: float = TAU * float(i) / 24.0
		pts.append(center + Vector2(cos(a)*radii.x, sin(a)*radii.y))
	draw_colored_polygon(pts, color)
